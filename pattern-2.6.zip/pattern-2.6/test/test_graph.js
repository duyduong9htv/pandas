var test_graph = {
    
    //----------------------------------------------------------------------------------------------
    // Unit tests for the graph.js module (see also test.html).

    TestCase: function() {
    	this.setUp = function() {
    		return;
    	};
    	this.tearDown = function() {
    		return;
    	};
    },

    //----------------------------------------------------------------------------------------------
    
    suite: function() {
        return [];
    }
    
}